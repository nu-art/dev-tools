import {DB_Object, DBProto, Proto_DB_Object, VersionsDeclaration} from '@nu-art/ts-common';

type VersionTypes_${EntityName} = {	'1.0.0': DB_${EntityName}}
type Versions = VersionsDeclaration<['1.0.0'], VersionTypes_${EntityName}>;
type Dependencies = {}
type UniqueKeys = '_id';
type GeneratedProps = never
type DBKey = '${EntityName.replaceAll("(?<=.)([A-Z])", "-$1").replace("_","-").toLowerCase()}'
type Proto = Proto_DB_Object<DB_${EntityName}, DBKey, GeneratedProps, Versions, UniqueKeys, Dependencies>;
export type DBProto_${EntityName} = DBProto<Proto>;
export type UI_${EntityName} = DBProto_${EntityName}['uiType'];

export type DB_${EntityName} = DB_Object & {
	'...': '...'
}