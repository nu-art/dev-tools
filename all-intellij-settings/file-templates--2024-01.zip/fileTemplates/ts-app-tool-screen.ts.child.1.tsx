import * as React from 'react';
import {FirebaseAnalyticsModule} from '@nu-art/firebase/frontend';
import {AppToolsScreen, ComponentSync, LL_V_L} from '@nu-art/thunderstorm/frontend';

type ATS_${ScreenName}_Props = {
	//
};
type ATS_${ScreenName}_State = {
	//
};

export class ATS_${ScreenName}
	extends ComponentSync<ATS_${ScreenName}_Props, ATS_${ScreenName}_State> {

	static screen: AppToolsScreen = {name: `DevTool - ${ScreenName}`, renderer: this};

	static defaultProps = {
		modules: [],
		pageTitle: () => this.screen.name
	};

	protected deriveStateFromProps(nextProps: ATS_${ScreenName}_Props, state = {} as ATS_${ScreenName}_State): ATS_${ScreenName}_State | undefined {
		return undefined;
	}

	constructor(p: ATS_${ScreenName}_Props) {
		super(p);
		// @ts-ignore
		FirebaseAnalyticsModule.setCurrentScreen(this.pageTitle);
	}

	render() {

		return <LL_V_L>
		App dev screen for ${ScreenName}
		</LL_V_L>;
	}
}