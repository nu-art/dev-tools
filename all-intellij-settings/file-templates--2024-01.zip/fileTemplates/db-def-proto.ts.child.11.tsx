import {GenericDropDownV3, TemplatingProps_TS_GenericDropDown, TS_MultiSelect_V2} from '@nu-art/thunderstorm/frontend';
import * as React from 'react';
import {DBProto_${EntityName}} from '../shared';
import {ModuleFE_${EntityName}} from './ModuleFE_${EntityName}';
import {DBItemDropDownMultiSelector} from '@nu-art/thunderstorm/frontend/components/_TS_MultiSelect/DBItemDropDownMultiSelector';
import {ICONSV4} from '@app/common/frontend/icons';


const Props_DropDown: TemplatingProps_TS_GenericDropDown<DBProto_${EntityName}> = {
	module: ModuleFE_${EntityName},
	modules: [ModuleFE_${EntityName}],
	mapper: item => [item.xxxxxxxxxxxx],
	placeholder: 'Choose a ${EntityName}',
	renderer: item => <div className="ll_h_c"> {item.xxxxxxxxxxxx} </div>
};

export const DropDown_${EntityName} = GenericDropDownV3.prepare(Props_DropDown);

const Props_MultiSelect = DBItemDropDownMultiSelector.propsV3({
	module: ModuleFE_${EntityName},
	itemRenderer: (item, onDelete) => {
		return !item ? <>Not Found</> : <><ICONSV4.x onClick={onDelete} className={'ts-icon__small'}/>{item.xxxxxxxxxxxx}</>;
	},
	uiSelector: DropDown_${EntityName}.selectable,
});

export const MultiSelect_${EntityName} = TS_MultiSelect_V2.prepare(Props_MultiSelect);

