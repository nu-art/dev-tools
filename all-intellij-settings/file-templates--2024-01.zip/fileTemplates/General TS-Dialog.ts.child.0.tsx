import * as React from 'react';
import {DialogButtons,EditableDBItemV3, LL_V_C, ModuleFE_Dialog, ModuleFE_Toaster, Props_TSDialog, TS_Dialog} from '@nu-art/thunderstorm/frontend';
import './Dialog_${FileName}.scss';


type DialogProps_${FileName} = {
}

type DialogState_${FileName} = {
//
}

export class Dialog_${FileName}
	extends TS_Dialog<DialogProps_${FileName}, DialogState_${FileName}> {

	static defaultProps = {
		dialogId: `dialog-${FileName.replaceAll("(?<=.)([A-Z])", "-$1").replace("_","-").toLowerCase()}`,
		className: `dialog-${FileName.replaceAll("(?<=.)([A-Z])", "-$1").replace("_","-").toLowerCase()}`
	};

	constructor(p: DialogProps_${FileName} & Props_TSDialog) {
		super(p);
		this.state = {};
	}

	static show() {
		ModuleFE_Dialog.show(<Dialog_${FileName}/>);
	}

	protected renderHeader = (): React.ReactNode => <div>Dialog ${FileName} Header</div>;
	protected renderBody = (): React.ReactNode => {
		return <LL_V_C>Dialog ${FileName} Body</LL_V_C>;
	};

	buttons = (): DialogButtons => {
		return {
			right: [{
				content: 'Todo',
				associatedKeys: ['enter'],
				renderer: TS_Dialog.busyButton,
				onClick: async () => {
					ModuleFE_Toaster.toastInfo('Hmmm... what should this button do in Dialog_${FileName}??', 10000);
					this.closeDialog();
				},
			}]
		};
	};
}