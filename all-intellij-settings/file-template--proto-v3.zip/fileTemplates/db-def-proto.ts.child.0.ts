import {DBDef_V3, tsValidateString} from '@nu-art/ts-common';
import {DBProto_${EntityName}} from './types';



const Validator_ModifiableProps: DBProto_${EntityName}['modifiablePropsValidator'] = {
	'...': tsValidateString()
};

const Validator_GeneratedProps: DBProto_${EntityName}['generatedPropsValidator'] = {
// 
};

export const DBDef_${EntityName}: DBDef_V3<DBProto_${EntityName}> = {
	modifiablePropsValidator: Validator_ModifiableProps,
	generatedPropsValidator:Validator_GeneratedProps,
	versions: ['1.0.0'],
	dbName: '${entity-name}',
	entityName: '${entity-name}',
};