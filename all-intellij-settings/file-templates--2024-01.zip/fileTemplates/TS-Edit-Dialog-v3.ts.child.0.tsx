import * as React from 'react';
import './Component_${FileName}.scss';
import {TS_EditableItemComponentV3} from '@nu-art/thunderstorm/frontend/components/TS_EditableItemComponent/TS_EditableItemComponent';


type Props_Component_${FileName} = {
//
}
type State_Component_${FileName} = {
//
}

export class Component_${FileName}
	extends TS_EditableItemComponentV3<DBProto_${EntityName}, Props_Component_${FileName}, State_Component_${FileName}> {

	render() {
		return <div className="component--${FileName.replaceAll("(?<=.)([A-Z])", "-$1").replace("_","-").toLowerCase()}">
		    ${EntityName} - ${FileName}
		</div>;
	}
}