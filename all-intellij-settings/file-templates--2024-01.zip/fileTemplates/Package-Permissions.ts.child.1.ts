export const DomainNamespace_${EntityName} = '${EntityName}';
export const PermissionKey_${EntityName}View = 'permission-key--${EntityName}-view';
export const PermissionKey_${EntityName}Edit = 'permission-key--${EntityName}-edit';
export const PermissionKey_${EntityName}Admin = 'permission-key--${EntityName}-admin';