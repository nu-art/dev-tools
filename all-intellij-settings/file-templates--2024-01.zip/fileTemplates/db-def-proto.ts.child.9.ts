export * from './ModuleFE_${EntityName}';
export * from './module-pack';