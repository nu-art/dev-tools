import {PermissionKey_FE} from '@nu-art/permissions/frontend/PermissionKey_FE';
import {PermissionKey_${EntityName}Admin, PermissionKey_${EntityName}Edit, PermissionKey_${EntityName}View} from '../shared/permissions';

export const PermissionKeyFE_${EntityName}View = new PermissionKey_FE(PermissionKey_${EntityName}View);
export const PermissionKeyFE_${EntityName}Edit = new PermissionKey_FE(PermissionKey_${EntityName}Edit);
export const PermissionKeyFE_${EntityName}Admin = new PermissionKey_FE(PermissionKey_${EntityName}Admin);