import {ComponentSync} from '@nu-art/thunderstorm/frontend';
import * as React from 'react';
import './${ComponentName}.scss'

type Props_${ComponentName} = {
//
}
type State_${ComponentName} = { 
//
}

export class Component_${ComponentName}
	extends ComponentSync<Props_${ComponentName}, State_${ComponentName}> {

	protected deriveStateFromProps(nextProps: Props_${ComponentName}, state: State_${ComponentName}) {
		state ??= this.state ? {...this.state} : {} as State_${ComponentName};
		return state;
	}

	render() {
		return <div className="${ComponentName.replace("_","-").toLowerCase()}">
		    Render ${ComponentName}
		</div>;
	}
}