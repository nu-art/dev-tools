import {ComponentSync} from '@nu-art/thunderstorm/frontend';
import * as React from 'react';
import './${ComponentName}.scss'

type Props_${ComponentName} = {
//
}
type State_${ComponentName} = { 
//
}

export class ${ComponentName}
	extends ComponentSync<Props_${ComponentName}, State_${ComponentName}> {

	render() {
		return <div className="${ComponentName.replaceAll("(?<=.)([A-Z])", "-$1").replace("_","-").toLowerCase()}">
		    Render ${ComponentName}
		</div>;
	}
}