import {defaultValueResolver, PermissionKey_BE} from '@nu-art/permissions/backend/PermissionKey_BE';
import {DefaultDef_Group, DefaultDef_Package} from '@nu-art/permissions/shared/types';
import {
	DefaultAccessLevel_Admin,
	DefaultAccessLevel_Delete,
	DefaultAccessLevel_NoAccess,
	DefaultAccessLevel_Read,
	DefaultAccessLevel_Write,
	DuplicateDefaultAccessLevels
} from '@nu-art/permissions/shared/consts';
import {filterInstances} from '@nu-art/ts-common';
import {ModuleBE_BaseDBV3} from '@nu-art/thunderstorm/backend';
import {DomainNamespace_${EntityName}, PermissionKey_${EntityName}Admin, PermissionKey_${EntityName}Edit, PermissionKey_${EntityName}View} from '../shared/permissions';
import {ModulePackBE_${EntityName}} from './module-pack';

export const Domain_${EntityName} = Object.freeze({
	_id: 'xxxxxxxxxxxxxxxxxxxxxxxxx',
	namespace: DomainNamespace_${EntityName}
});

const OtherPermissionDependency = {};

export const PermissionGroup_${EntityName}_NoAccess: DefaultDef_Group = {
	_id: 'xxxxxxxxxxxxxxxxxxxxxxxxx',
	name: `${DS}{DomainNamespace_${EntityName}}/No Access`,
	accessLevels: {
		[DomainNamespace_${EntityName}]: DefaultAccessLevel_NoAccess.name,
	},
};

export const PermissionGroup_${EntityName}_Viewer: DefaultDef_Group = {
	_id: 'xxxxxxxxxxxxxxxxxxxxxxxxx',
	name: `${DS}{DomainNamespace_${EntityName}}/Viewer`,
	accessLevels: {
		[DomainNamespace_${EntityName}]: DefaultAccessLevel_Read.name,
		...OtherPermissionDependency
	},
};
export const PermissionGroup_${EntityName}_Editor: DefaultDef_Group = {
	_id: 'xxxxxxxxxxxxxxxxxxxxxxxxx',
	name: `${DS}{DomainNamespace_${EntityName}}/Editor`,
	accessLevels: {
		[DomainNamespace_${EntityName}]: DefaultAccessLevel_Delete.name,
		...OtherPermissionDependency
	},
};

export const PermissionGroup_${EntityName}_Admin: DefaultDef_Group = {
	_id: 'xxxxxxxxxxxxxxxxxxxxxxxxx',
	name: `${DS}{DomainNamespace_${EntityName}}/Admin`,
	accessLevels: {
		[DomainNamespace_${EntityName}]: DefaultAccessLevel_Admin.name,
		...OtherPermissionDependency
	},
};

export const PermissionGroups_${EntityName}: DefaultDef_Group[] = [
	PermissionGroup_${EntityName}_NoAccess,
	PermissionGroup_${EntityName}_Viewer,
	PermissionGroup_${EntityName}_Editor,
	PermissionGroup_${EntityName}_Admin,
];

export const PermissionKeyBE_${EntityName}View = new PermissionKey_BE(PermissionKey_${EntityName}View, () => defaultValueResolver(DomainNamespace_${EntityName}, DefaultAccessLevel_Read.value));
export const PermissionKeyBE_${EntityName}Edit = new PermissionKey_BE(PermissionKey_${EntityName}Edit, () => defaultValueResolver(DomainNamespace_${EntityName}, DefaultAccessLevel_Write.value));
export const PermissionKeyBE_${EntityName}Admin = new PermissionKey_BE(PermissionKey_${EntityName}Admin, () => defaultValueResolver(DomainNamespace_${EntityName}, DefaultAccessLevel_Admin.value));

export const PermissionsPackage_${EntityName}: DefaultDef_Package = {
	name: Domain_${EntityName}.namespace,
    groups: PermissionGroups_${EntityName},
	domains: [
		{
			...Domain_${EntityName},
			levels: [...DuplicateDefaultAccessLevels(Domain_${EntityName}._id)],
			dbNames: [
				...filterInstances(ModulePackBE_${EntityName} as ModuleBE_BaseDBV3<any>[])
					.filter(module => module.dbDef && module.dbDef.dbName)
					.map(module => module.dbDef),
			].map(dbDef => dbDef.dbName)
		}
	]
};