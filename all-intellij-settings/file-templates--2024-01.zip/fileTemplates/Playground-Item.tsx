import * as React from 'react';
import { ComponentSync } from '@nu-art/thunderstorm/frontend';

type State = {};

class PgDev_${Playground_Name}_Class
	extends ComponentSync<{}, State> {

	protected deriveStateFromProps(nextProps: any): State {
		return {};
	}

	render() {
		return <div className={'pg-dev-${Playground_Name_Lowercase}'}></div>	
	}
}

export const PgDev_${Playground_Name} = {name: '${Playground_Name}', renderer: PgDev_${Playground_Name}_Class};