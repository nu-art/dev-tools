// FileName: ${FileName}
export * from "./Dialog_${FileName}"