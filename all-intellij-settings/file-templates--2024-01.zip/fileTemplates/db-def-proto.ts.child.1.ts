import {apiWithBody, apiWithQuery, ModuleFE_v3_BaseApi} from '@nu-art/thunderstorm/frontend';
import {ApiDefCaller} from '@nu-art/thunderstorm';
import {DispatcherDef, ThunderDispatcherV3} from '@nu-art/thunderstorm/frontend/core/db-api-gen/v3_types';
import {ApiDef_${EntityName}, ApiStruct_${EntityName}, DBDef_${EntityName}, DBProto_${EntityName}} from '../shared';


export type DispatcherType_${EntityName} = DispatcherDef<DBProto_${EntityName}, `__on${EntityName}Updated`>;

export const dispatch_on${EntityName}Changed = new ThunderDispatcherV3<DispatcherType_${EntityName}>('__on${EntityName}Updated');

export class ModuleFE_${EntityName}_Class
	extends ModuleFE_v3_BaseApi<DBProto_${EntityName}>
	implements ApiDefCaller<ApiStruct_${EntityName}> {

	_v1: ApiDefCaller<ApiStruct_${EntityName}>['_v1'];

	constructor() {
		super(DBDef_${EntityName}, dispatch_on${EntityName}Changed);
		this._v1 = {
			'?': apiWithBody(ApiDef_${EntityName}._v1['?']),
			'??': apiWithQuery(ApiDef_${EntityName}._v1['??']),
		};

	}

}

export const ModuleFE_${EntityName} = new ModuleFE_${EntityName}_Class();

