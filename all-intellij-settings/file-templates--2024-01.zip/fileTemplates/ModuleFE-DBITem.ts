import {ApiCallerEventType, BaseDB_ApiGeneratorCaller} from "@nu-art/db-api-generator/frontend";

import {ThunderDispatcher} from "@nu-art/thunderstorm/frontend";

export interface On${MODULE_NAME}Updated {
	__on${MODULE_NAME}Updated: (...params: ApiCallerEventType) => void;
}

export const dispatch_on${MODULE_NAME}ListChanged = new ThunderDispatcher<On${MODULE_NAME}Updated, '__on${MODULE_NAME}Updated'>('__on${MODULE_NAME}Updated');

export class ${MODULE_NAME}ModuleFE_Class
	extends BaseDB_ApiGeneratorCaller<${TYPE_NAME}> {


	constructor() {
		super({key: "${API_PATH}", relativeUrl: "/v1/${API_PATH}"});
		this.setDefaultDispatcher(dispatch_on${MODULE_NAME}ListChanged);
	}
}

export const ${MODULE_NAME}ModuleFE = new ${MODULE_NAME}ModuleFE_Class();
