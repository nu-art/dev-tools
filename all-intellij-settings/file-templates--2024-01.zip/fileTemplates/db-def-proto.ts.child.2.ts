import {DBApiConfigV3, ModuleBE_BaseDBV3,} from '@nu-art/thunderstorm/backend';
import {DBDef_${EntityName}, DBProto_${EntityName}} from '../shared';


type Config = DBApiConfigV3<DBProto_${EntityName}> & {
// 	
}

export class ModuleBE_${EntityName}DB_Class
	extends ModuleBE_BaseDBV3<DBProto_${EntityName}, Config> {

	constructor() {
		super(DBDef_${EntityName});
	}
}

export const ModuleBE_${EntityName}DB = new ModuleBE_${EntityName}DB_Class();
