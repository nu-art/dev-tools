import * as React from 'react';
import {DialogButtons, LL_V_C, ModuleFE_Dialog, ModuleFE_Toaster, Props_TSDialog, TS_Dialog} from '@nu-art/thunderstorm/frontend';
import {EditableDBItemV3} from '@nu-art/thunderstorm/frontend/utils/EditableDBItemV3';
import './Dialog_${EntityName}.scss';


type DialogProps_${EntityName} = {
	editable: EditableDBItemV3<DBProto_${EntityName}>,
}

type DialogState_${EntityName} = {
//
}

export class Dialog_${EntityName}
	extends TS_Dialog<DialogProps_${EntityName}, DialogState_${EntityName}> {

	static defaultProps = {
		dialogId: `dialog-${EntityName}`,
		className: `dialog-${EntityName}`
	};

	constructor(p: DialogProps_${EntityName} & Props_TSDialog) {
		super(p);
		this.state = {};
	}

	static show(editable: EditableDBItemV3<DBProto_${EntityName}>) {
		ModuleFE_Dialog.show(<Dialog_${EntityName} editable={editable}/>);
	}

	protected renderHeader = (): React.ReactNode => <div>Dialog ${EntityName} Header</div>;
	protected renderBody = (): React.ReactNode => {
		return <LL_V_C>Dialog ${EntityName} Body</LL_V_C>;
	};

	buttons = (): DialogButtons => {
		return {
			right: [{
				content: 'Todo',
				associatedKeys: ['enter'],
				renderer: TS_Dialog.busyButton,
				onClick: async () => {
					ModuleFE_Toaster.toastInfo('Hmmm... what should this button do in Dialog_${EntityName}??', 10000);
					this.closeDialog();
				},
			}]
		};
	};
}