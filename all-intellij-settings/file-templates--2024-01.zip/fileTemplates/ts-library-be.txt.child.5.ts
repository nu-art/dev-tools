import {Module} from '@nu-art/ts-common';


type Config ={
// config here
}

export class ModuleBE_${ModuleName}_Class
	extends Module<Config> {

	constructor(tag?: string) {
	    super(tag)
	}
	
	init() {
	    // module init here
	}
}

export const ModuleBE_${ModuleName} = new ModuleBE_${ModuleName}_Class();
