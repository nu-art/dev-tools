import { ModuleFE_${EntityName} } from "./ModuleFE_${EntityName}";


export const ModulePackFE_${EntityName} = [ModuleFE_${EntityName}];