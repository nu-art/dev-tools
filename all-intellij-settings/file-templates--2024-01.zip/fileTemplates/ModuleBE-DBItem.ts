import {BaseDB_ApiGenerator, tsValidateUniqueId,} from "@nu-art/db-api-generator/backend";
import {tsValidateArray, tsValidateBoolean, ValidatorTypeResolver} from "@nu-art/ts-common";

export class ${MODULE_NAME}ModuleBE_Class
	extends BaseDB_ApiGenerator<${TYPE_NAME}> {

	static validator: ValidatorTypeResolver<${TYPE_NAME}> = {
		...BaseDB_ApiGenerator.__validator,
		
	};

	constructor() {
		super("${API_PATH}", ${MODULE_NAME}ModuleBE_Class.validator, "${API_PATH}");
	}
}

export const ${MODULE_NAME}ModuleBE = new ${MODULE_NAME}ModuleBE_Class();