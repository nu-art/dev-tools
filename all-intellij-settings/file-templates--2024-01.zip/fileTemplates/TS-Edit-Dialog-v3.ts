// FileName: ${FileName}
// EntityName: ${EntityName}
export * from "./Dialog_${FileName}"
export * from "./Component_${FileName}"