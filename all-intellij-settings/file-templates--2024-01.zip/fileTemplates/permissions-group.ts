//GroupVarName=${GroupVarName}
//GroupLabel=${GroupLabel}
//GroupId=${GroupId}

import {DefaultDef_Group} from '@nu-art/permissions/shared/types';
import {DefaultAccessLevel_Read} from '@nu-art/permissions/shared/consts';


export const PermissionsGroupId_${GroupVarName} = ${GroupId};

const _PermissionsGroup_${GroupVarName}: DefaultDef_Group = {
	_id: PermissionsGroupId_${GroupVarName},
	name: '${GroupLabel}',
	accessLevels: {
//		[PermissionsDomain_YourDomainDefHere.namespace]: DefaultAccessLevel_Read.name
	}
};

export const PermissionsGroup_${GroupVarName} = Object.freeze(_PermissionsGroup_${GroupVarName});
