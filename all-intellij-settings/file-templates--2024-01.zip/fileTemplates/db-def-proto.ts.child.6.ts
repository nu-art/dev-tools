import {createApisForDBModuleV3} from '@nu-art/thunderstorm/backend';
import {ModuleBE_${EntityName}DB} from './ModuleBE_${EntityName}DB';


export const ModulePackBE_${EntityName}DB = [ModuleBE_${EntityName}DB, createApisForDBModuleV3(ModuleBE_${EntityName}DB)];