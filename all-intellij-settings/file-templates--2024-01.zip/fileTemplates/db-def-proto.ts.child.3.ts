import {ApiDefResolver, BodyApi,QueryApi, HttpMethod} from '@nu-art/thunderstorm';
import {DBDef_${EntityName}} from './db-def';


export type RequestType = {
//
};
export type ResponseType = {
//
};

export type ApiStruct_${EntityName} = {
	_v1: {
		"?": BodyApi<ResponseType, RequestType>,
		"??": QueryApi<ResponseType, RequestType>,
		
	}
}

export const ApiDef_${EntityName}: ApiDefResolver<ApiStruct_${EntityName}> = {
	_v1: {
		"?": {method: HttpMethod.POST, path: `v1/${DS}{DBDef_${EntityName}.dbName}/post`},
		"??": {method: HttpMethod.GET, path: `v1/${DS}{DBDef_${EntityName}.dbName}/get`},
	}
};
